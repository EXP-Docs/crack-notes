

   Language file for Exeinfo Pe v.0.0.5.4




If any body need translate Exeinfo Pe language file (.lng) , 

this is neutral english file for Exeinfo Pe v.0.0.5.4



How to : 

Please edit file with text editor and copy file to Exeinfo\languages\  directory



Translation example :

PNG_rip=*png picture Ripper

to German language :

PNG_rip=png bilder Ripper



if problem you can first set charset : 

example:

_Charset = GB2312  -> for example this is China Simplified


 

A.S.L


